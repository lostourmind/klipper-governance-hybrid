#!/usr/bin/env python3
import argparse, sys, re, os, pathlib

RULES = [
    ("expr_filter_in_mustache", re.compile(r"\{\{\s*[^}]*\|[^}]*\}\}"), "Filters inside {{ }} are forbidden; precompute with {% set %}."),
    ("inline_control_blocks",   re.compile(r"\{\%\s*(if|for|elif|else|endif|endfor)[^%]*\%\}.*\{\%\s*(set|if|for|endif|endfor)[^%]*\%\}"), "Inline control blocks must be split across lines."),
    ("respond_semicolon",       re.compile(r"RESPOND\s+MSG\s*=\s*\"[^\"\n]*;[^\"\n]*\""), "Semicolons inside RESPOND messages are not allowed."),
    ("respond_square_brackets", re.compile(r"RESPOND\s+MSG\s*=\s*\"[^\"\n]*\[[^\"\n]*\][^\"\n]*\""), "Square brackets in RESPOND messages are not allowed."),
    ("m118_usage",              re.compile(r"^\s*M118\b", re.M), "M118 present; prefer RESPOND (override with --allow-m118)."),
    ("non_ascii",               re.compile(r"[^\x00-\x7F]"), "Non-ASCII characters detected; use ASCII only."),
    ("save_config_below_marker",re.compile(r"(?is)^\s*#.*?SAVE_CONFIG.*?$.*?\n(?!#\s*This.*|#\s*END|;|$)"), "Content appears below SAVE_CONFIG marker; forbidden."),
    ("pipe_in_mustache_any",    re.compile(r"\{\{[^}]*\|[^}]*\}\}"), "Pipe '|' in {{ }} not allowed (implies filters)."),
]

def find_violations(text, allow_m118=False, strict_ascii=False):
    violations = []
    for name, pattern, msg in RULES:
        if name == "m118_usage" and allow_m118:
            continue
        if name == "non_ascii" and not strict_ascii:
            continue
        for m in pattern.finditer(text):
            # locate line number
            start = m.start()
            line_no = text.count("\\n", 0, start) + 1
            line = text.splitlines()[line_no-1][:200]
            violations.append((name, msg, line_no, line))
    return violations

def collect_paths(paths):
    files = []
    for p in paths:
        pth = pathlib.Path(p)
        if pth.is_dir():
            for ext in ("*.cfg","*.conf","*.gcode","*.macro","*.txt","*.ini"):
                files.extend([str(x) for x in pth.rglob(ext)])
        elif pth.exists():
            files.append(str(pth))
    return sorted(set(files))

def main():
    ap = argparse.ArgumentParser(description="Lint Klipper macros for compat Jinja and governance constraints.")
    ap.add_argument("--paths", nargs="+", default=["."], help="Files or folders to scan")
    ap.add_argument("--allow-m118", action="store_true", help="Allow M118 usage")
    ap.add_argument("--strict-ascii", action="store_true", help="Fail on non-ASCII characters")
    args = ap.parse_args()

    files = collect_paths(args.paths)
    if not files:
        print("No files found.", file=sys.stderr)
        return 2

    total = 0
    failed = 0
    for f in files:
        try:
            with open(f, "r", encoding="utf-8", errors="ignore") as fh:
                txt = fh.read()
        except Exception as e:
            print(f"[ERROR] {f}: {e}", file=sys.stderr)
            failed = 1
            continue
        v = find_violations(txt, allow_m118=args.allow_m118, strict_ascii=args.strict_ascii)
        if v:
            print(f"\n✗ {f}")
            for name, msg, ln, line in v:
                print(f"  - {name} @ line {ln}: {msg}")
                print(f"    > {line}")
            failed = 1
        total += 1

    if failed:
        print("\nLint failed. Fix violations above.", file=sys.stderr)
        return 1
    else:
        print(f"OK: {total} file(s) passed.")
        return 0

if __name__ == "__main__":
    sys.exit(main())
