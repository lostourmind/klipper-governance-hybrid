# Klipper Macro Governance – Preventive Tooling (Compat Jinja)

This add-on stops the class of Jinja parse errors you hit (`expected token ':' got '}'`) **before** macros reach Klipper.

## What it enforces
- **No filters inside `{{ ... }}`** (precompute with `{% set %}`).
- **No inline control blocks** (never `{% if ... %}{% set ... %}{% endif %}` on one line).
- **RESPOND discipline**: no `;` or `[]` inside messages; indent under `gcode:`; prefer `RESPOND` over `M118`.
- **ASCII-only** in macros.
- **Ban pipes `|` inside `{{ ... }}`** (signals filters in expressions).
- **No `M118` unless explicitly allowed** (toggle flag).
- **Optional**: Forbid `SAVE_CONFIG` content edits.

## How to use
1) Drop `tools/klipper_macro_lint.py` into your repo and add the pre-commit hook:
   ```bash
   cp hooks/pre-commit .git/hooks/pre-commit
   chmod +x .git/hooks/pre-commit
   ```
2) Commit as usual. The hook blocks commits that violate rules.
3) CI: run `python tools/klipper_macro_lint.py --paths <files or folders>` in your pipeline.

## Configuration
- Allow `M118`: `--allow-m118`
- Fail on non-ASCII: `--strict-ascii`
- File globs: `--paths printer.cfg macros/ *.cfg`

## Exit codes
- 0: OK
- 1: Violations found
- 2: Internal error
