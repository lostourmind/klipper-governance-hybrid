# Klipper Governance Agent Package (v2)
- agent/Klipper_Governance_Agent_Unified_v2.md
- agent/macros/GOV_CANARY_ADAPTIVE_PREP.cfg (Klipper-compat)
- tools/* (linter + fixer), hooks/pre-commit, .klipperlint.toml
- CHAT_LOADER.txt (copy/paste for any new chat to toggle this profile)
